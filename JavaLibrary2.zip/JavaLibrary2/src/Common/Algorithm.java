package Common;

public class Algorithm {
    
}
